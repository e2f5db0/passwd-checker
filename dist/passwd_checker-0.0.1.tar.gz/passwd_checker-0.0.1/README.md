
passwd_checker
--------------

Check a password against Daniel Miessler's SecLists & other custom requirements
